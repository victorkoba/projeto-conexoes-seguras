const express = require('express');
const session = require('express-session');
const path = require('path');

const app = express();

app.use(express.urlencoded({ extended: true }));

app.use(session({
    secret: 'segredo123',
    resave: false,
    saveUninitialized: false,
    cookie: {
        secure: false,
        httpOnly: true
    }
}));

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'views/login.html'));
});

app.post('/login', (req, res) => {
    const { usuario, senha } = req.body;

    if (usuario === 'admin' && senha === '123') {
        req.session.usuario = usuario;
        return res.redirect('/index');
    }

    res.send('Login inválido');
});

app.get('/index', (req, res) => {
    if (!req.session.usuario) {
        return res.redirect('/');
    }

    res.sendFile(path.join(__dirname, 'views/index.html'));
});

app.get('/logout', (req, res) => {
    req.session.destroy();
    res.redirect('/');
});

app.listen(3000, () => {
    console.log('Servidor rodando em http://localhost:3000');
});